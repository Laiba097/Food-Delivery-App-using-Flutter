// model/menu_item.dart

class MenuItem {
  final int id;
  final String name;
  final double price;
  final String imagePath; // New property for image path

  MenuItem({
    required this.id,
    required this.name,
    required this.price,
    required this.imagePath,
  });
}
