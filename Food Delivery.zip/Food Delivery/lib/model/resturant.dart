import 'package:flutter/material.dart';
import 'package:foodtime/model/menu_item.dart';


class Restaurant {
  final int id;
  final String name;
  final String description;
  final double deliveryFee;
  final int deliveryTime;
  final String imagePath;
  final List<MenuItem> items;

  Restaurant({
    required this.id,
    required this.name,
    required this.description,
    required this.deliveryFee,
    required this.deliveryTime,
    required this.imagePath,
    required this.items,
  });
}
