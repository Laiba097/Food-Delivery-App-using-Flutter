import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:foodtime/model/menu_item.dart';
import 'package:foodtime/model/resturant.dart';
import 'package:foodtime/toast.dart';

class AddToCartScreen extends StatefulWidget {
  final Map<int, int> cart;
  final Restaurant restaurant;

  AddToCartScreen({required this.cart, required this.restaurant});

  @override
  _AddToCartScreenState createState() => _AddToCartScreenState();
}

class _AddToCartScreenState extends State<AddToCartScreen> {
  late Map<MenuItem, int> _cartItems;

  @override
  void initState() {
    super.initState();
    _initializeCartItems();
  }

  void _initializeCartItems() {
    _cartItems = {};
    widget.cart.forEach((itemId, quantity) {
      final item = widget.restaurant.items.firstWhere((menuItem) => menuItem.id == itemId);
      _cartItems[item] = quantity;
    });
  }

  void _addItem(MenuItem item) {
    setState(() {
      _cartItems.update(item, (quantity) => quantity + 1, ifAbsent: () => 1);
    });
  }

  void _removeItem(MenuItem item) {
    setState(() {
      if (_cartItems.containsKey(item) && _cartItems[item]! > 0) {
        _cartItems.update(item, (quantity) => quantity - 1);
        if (_cartItems[item] == 0) {
          _cartItems.remove(item);
        }
      }
    });
  }

  double _calculateTotal() {
    double total = 0;
    _cartItems.forEach((item, quantity) {
      total += item.price * quantity;
    });
    return total;
  }

  void _navigateToCheckout(BuildContext context) {
    double totalBill = _calculateTotal();
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CheckoutScreen(totalBill: totalBill, cartItems: _cartItems),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.teal,
      appBar: AppBar(
        title: Center(
          child: Text(
            'Your Cart',
            style: TextStyle(color: Colors.white), // Text color
          ),
        ),
        backgroundColor: Colors.teal, // App bar background color
        iconTheme: IconThemeData(color: Colors.white), // Set back arrow color to white
      ),
      body: ListView.builder(
        itemCount: _cartItems.length,
        itemBuilder: (context, index) {
          final item = _cartItems.keys.elementAt(index);
          final quantity = _cartItems[item];
          return Container(
            margin: EdgeInsets.symmetric(vertical: 4, horizontal: 8),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(8),
              boxShadow: [
                BoxShadow(
                  color: Colors.black12,
                  blurRadius: 4,
                  spreadRadius: 2,
                ),
              ],
            ),
            child: ListTile(
              leading: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.asset(
                  item.imagePath,
                  width: 50,
                  height: 50,
                  fit: BoxFit.cover,
                ),
              ),
              title: Text(
                item.name,
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.teal),
              ),
              subtitle: Text(
                'Rs${item.price.toStringAsFixed(2)} x $quantity',
                style: TextStyle(fontSize: 14, color: Colors.black54),
              ),
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: Icon(Icons.remove_circle_outline),
                    onPressed: () => _removeItem(item),
                    color: Colors.teal,
                  ),
                  Text('$quantity', style: TextStyle(fontSize: 16, color: Colors.teal)),
                  IconButton(
                    icon: Icon(Icons.add_circle_outline),
                    onPressed: () => _addItem(item),
                    color: Colors.teal,
                  ),
                ],
              ),
            ),
          );
        },
      ),
      bottomNavigationBar: _cartItems.isNotEmpty
          ? BottomAppBar(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Total: Rs${_calculateTotal().toStringAsFixed(2)}',
                style: TextStyle(fontSize: 18, color: Colors.white),
              ),
              ElevatedButton(
                onPressed: () => _navigateToCheckout(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                  padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                ),
                child: Text(
                  'Checkout',
                  style: TextStyle(fontSize: 18, color: Colors.teal),
                ),
              ),
            ],
          ),
        ),
        color: Colors.teal,
      )
          : null,
    );
  }
}

class CheckoutScreen extends StatelessWidget {
  final double totalBill;
  final Map<MenuItem, int> cartItems;
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneNumberController = TextEditingController();
  final TextEditingController _addressController = TextEditingController();

  CheckoutScreen({required this.totalBill, required this.cartItems});

  void _confirmOrder(BuildContext context) {
    if (_formKey.currentState!.validate()) {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text("Order Confirmed"),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Your order has been confirmed."),
                Text("Total Bill: Rs ${totalBill.toStringAsFixed(2)}"),
                Text("You will pay on receiving your order."),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop(); // Close the dialog
                  // Proceed with saving order to Firestore
                  saveOrderToFirestore();
                  // Show a confirmation message
                  showToast(message: 'Order confirmed!');
                },
                child: Text("OK"),
              ),
            ],
          );
        },
      );
    }
  }

  Future<void> saveOrderToFirestore() async {
    try {
      // Convert cart items to a map suitable for Firestore
      Map<String, dynamic> cartItemsMap = {};
      cartItems.forEach((item, quantity) {
        cartItemsMap[item.id.toString()] = {
          'name': item.name,
          'quantity': quantity,
          'price': item.price
        };
      });

      await FirebaseFirestore.instance.collection('orders').add({
        'name': _nameController.text,
        'phoneNumber': _phoneNumberController.text,
        'address': _addressController.text,
        'totalBill': totalBill,
        'items': cartItemsMap,
        'timestamp': Timestamp.now(),
      });
    } catch (e) {
      print('Error adding order to Firestore: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.teal,
      appBar: AppBar(
        title: Center(child: Text('Checkout', style: TextStyle(color: Colors.white))),
        backgroundColor: Colors.teal,
        iconTheme: IconThemeData(color: Colors.white), // Set back arrow color to white
      ),
      body: Stack(
        children: [
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: Image.asset(
              'images/form.png',
              height: 100,
            ),
          ),
          Center(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  SizedBox(height: 10),
                  Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        TextFormField(
                          controller: _nameController,
                          decoration: InputDecoration(
                            labelText: 'Name',
                            labelStyle: TextStyle(color: Colors.white),
                            prefixIcon: Icon(Icons.person, color: Colors.white),
                            enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: Colors.white),
                            ),
                            focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: Colors.white),
                            ),
                          ),
                          style: TextStyle(color: Colors.white),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your name';
                            }
                            return null;
                          },
                        ),
                        SizedBox(height: 10),
                        TextFormField(
                          controller: _phoneNumberController,
                          decoration: InputDecoration(
                            labelText: 'Phone Number',
                            labelStyle: TextStyle(color: Colors.white),
                            prefixIcon: Icon(Icons.phone, color: Colors.white),
                            enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: Colors.white),
                            ),
                            focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: Colors.white),
                            ),
                          ),
                          style: TextStyle(color: Colors.white),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your phone number';
                            }
                            return null;
                          },
                        ),
                        SizedBox(height: 10),
                        TextFormField(
                          controller: _addressController,
                          decoration: InputDecoration(
                            labelText: 'Address',
                            labelStyle: TextStyle(color: Colors.white),
                            prefixIcon: Icon(Icons.location_on, color: Colors.white),
                            enabledBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: Colors.white),
                            ),
                            focusedBorder: UnderlineInputBorder(
                              borderSide: BorderSide(color: Colors.white),
                            ),
                          ),
                          style: TextStyle(color: Colors.white),
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your address';
                            }
                            return null;
                          },
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 20),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ElevatedButton(
                        onPressed: () => _confirmOrder(context),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          padding: EdgeInsets.symmetric(vertical: 16, horizontal: 24),
                        ),
                        child: Text(
                          'Confirm Order',
                          style: TextStyle(fontSize: 18, color: Colors.teal),
                        ),
                      ),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.pushNamed(context, '/home');
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          padding: EdgeInsets.symmetric(vertical: 16, horizontal: 24),
                        ),
                        child: Text(
                          'New Order',
                          style: TextStyle(fontSize: 18, color: Colors.teal),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          FirebaseAuth.instance.signOut();
          Navigator.pushNamed(context, "/login");
          showToast(message: "You have been successfully signed out.");
        },
        tooltip: 'Sign Out',
        child: Icon(Icons.logout, color: Colors.teal),
      ),
    );
  }
}
