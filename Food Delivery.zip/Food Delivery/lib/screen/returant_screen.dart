import 'package:flutter/material.dart';
import 'package:foodtime/model/resturant.dart';
import 'package:foodtime/screen/add_to_cart_screen.dart';

class RestaurantScreen extends StatefulWidget {
  final Restaurant restaurant;

  RestaurantScreen({required this.restaurant});

  @override
  _RestaurantScreenState createState() => _RestaurantScreenState();
}

class _RestaurantScreenState extends State<RestaurantScreen> {
  Map<int, int> _cart = {};

  void _addItem(int id) {
    setState(() {
      _cart.update(id, (quantity) => quantity + 1, ifAbsent: () => 1);
    });
  }

  void _removeItem(int id) {
    setState(() {
      if (_cart.containsKey(id) && _cart[id]! > 0) {
        _cart.update(id, (quantity) => quantity - 1);
        if (_cart[id] == 0) {
          _cart.remove(id);
        }
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.teal,
      appBar: AppBar(
        backgroundColor: Colors.teal,
        title: Text(
          widget.restaurant.name,
          style: TextStyle(color: Colors.white), // Set app bar title color to white
        ),
        iconTheme: IconThemeData(color: Colors.white), // Set back arrow color to white
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              decoration: BoxDecoration(
                image: DecorationImage(
                  image: AssetImage(widget.restaurant.imagePath),
                  fit: BoxFit.cover,
                ),
              ),
              width: double.infinity,
              height: 200,
            ),
            ListView.builder(
              shrinkWrap: true,
              itemCount: widget.restaurant.items.length,
              itemBuilder: (context, index) {
                final menuItem = widget.restaurant.items[index];
                return Container(
                  margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 4,
                        spreadRadius: 2,
                      ),
                    ],
                  ),
                  child: ListTile(
                    title: Text(
                      menuItem.name,
                      style: TextStyle(fontWeight: FontWeight.bold, color: Colors.teal),
                    ),
                    subtitle: Text(
                      'Rs${menuItem.price}',
                      style: TextStyle(color: Colors.black54),
                    ),
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.asset(
                        menuItem.imagePath,
                        width: 60,
                        height: 60,
                        fit: BoxFit.cover,
                      ),
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        IconButton(
                          icon: Icon(Icons.remove_circle_outline),
                          onPressed: () => _removeItem(menuItem.id),
                          color: Colors.teal,
                        ),
                        Text(
                          _cart[menuItem.id]?.toString() ?? '0',
                          style: TextStyle(color: Colors.teal),
                        ),
                        IconButton(
                          icon: Icon(Icons.add_circle_outline),
                          onPressed: () => _addItem(menuItem.id),
                          color: Colors.teal,
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => AddToCartScreen(cart: _cart, restaurant: widget.restaurant),
                    ),
                  );
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  padding: EdgeInsets.symmetric(vertical: 15, horizontal: 25),
                ),
                child: Text(
                  'Add to Cart',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Colors.teal,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
