import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:foodtime/model/menu_item.dart';
import 'package:foodtime/model/resturant.dart';
import 'package:foodtime/screen/returant_screen.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  late User? _user;

  final List<Restaurant> restaurants = [
    Restaurant(
      id: 1,
      name: 'Burger Lovers',
      description: 'Delicious and juicy burgers for burger lovers.',
      deliveryFee: 0,
      deliveryTime: 30,
      imagePath: 'images/hamburger.jpg',
      items: [
        MenuItem(id: 1, name: 'Shami Burger', price: 500, imagePath: 'images/shami.jpg'),
        MenuItem(id: 2, name: 'Zinger Burger', price: 450, imagePath: 'images/zinger.jpg'),
        MenuItem(id: 3, name: 'Beef Burger', price: 450, imagePath: 'images/beefb.jpg'),
        MenuItem(id: 4, name: 'Chicken Burger', price: 550, imagePath: 'images/chicken.jpeg'),
        MenuItem(id: 5, name: 'Special Burger', price: 600, imagePath: 'images/cheseb.jpg'),
      ],
    ),
    Restaurant(
      id: 2,
      name: 'Biryani Lover',
      description: 'Biryani is Love',
      deliveryFee: 0,
      deliveryTime: 30,
      imagePath: 'images/Love.jpg',
      items: [
        MenuItem(id: 1, name: 'Beef Biryani', price: 400, imagePath: 'images/beefBiryani.jpg'),
        MenuItem(id: 2, name: 'Chicken Biryani', price:300 , imagePath: 'images/chickenB.jpg'),
        MenuItem(id: 3, name: 'Mutton Biryani', price: 500, imagePath: 'images/muttonB.jpg'),
        MenuItem(id: 4, name: 'Fish Biryani', price: 450, imagePath: 'images/fishB.jpg'),
        MenuItem(id: 5, name: 'Vegetable Biryani', price: 250, imagePath: 'images/vegB.jpg'),
      ],
    ),
    Restaurant(
      id: 3,
      name: 'Healthy Food',
      description: 'Wholesome and nutritious meals for a healthy lifestyle.',
      deliveryFee: 0,
      deliveryTime: 30,
      imagePath: 'images/salad9.jpg',
      items: [
        MenuItem(id: 1, name: 'Caesar Salad', price: 250, imagePath: 'images/salad2.png'),
        MenuItem(id: 2, name: 'Greek Salad', price: 250, imagePath: 'images/salad3.png'),
        MenuItem(id: 3, name: 'Quinoa Salad', price: 300, imagePath: 'images/salad4.png'),
        MenuItem(id: 4, name: 'Avocado Salad', price: 350, imagePath: 'images/avacados.jpg'),
        MenuItem(id: 5, name: 'Fruit Salad', price: 500, imagePath: 'images/fruits.jpg'),
      ],
    ),
    Restaurant(
      id: 4,
      name: 'Juice',
      description: 'Freshly squeezed juices to refresh your day.',
      deliveryFee: 0,
      deliveryTime: 30,
      imagePath: 'images/fruit juice.jpg',
      items: [
        MenuItem(id: 1, name: 'Orange Juice', price: 200, imagePath: 'images/orangej.jpg'),
        MenuItem(id: 2, name: 'Apple Juice', price: 230, imagePath: 'images/applej.jpg'),
        MenuItem(id: 3, name: 'Mango Juice', price: 300, imagePath: 'images/mangoj.jpg'),
        MenuItem(id: 4, name: 'Pineapple Juice', price: 200, imagePath: 'images/pineapplej.jpg'),
        MenuItem(id: 5, name: 'Mixed Fruit Juice', price: 200, imagePath: 'images/mixj.jpg'),
      ],
    ),
    Restaurant(
      id: 5,
      name: 'Gourmet Platters',
      description: 'Exquisite platters for gourmet lovers.',
      deliveryFee: 0,
      deliveryTime: 30,
      imagePath: 'images/platters.jpg',
      items: [
        MenuItem(id: 1, name: 'Cheese Platter', price: 1000, imagePath: 'images/cplatter.jpg'),
        MenuItem(id: 2, name: 'Fruit Platter', price: 900, imagePath: 'images/fplatter.jpg'),
        MenuItem(id: 3, name: 'Vegetable Platter', price: 800, imagePath: 'images/vplatter.jpg'),
        MenuItem(id: 4, name: 'Seafood Platter', price: 1500, imagePath: 'images/seaplatter.jpg'),
        MenuItem(id: 5, name: 'Beef Platter', price: 2000, imagePath: 'images/beefplatter.jpg'),
      ],
    ),
    Restaurant(
      id: 6,
      name: 'Sushi Delight',
      description: 'Fresh sushi made to order.',
      deliveryFee: 0,
      deliveryTime: 30,
      imagePath: 'images/sushi.jpg',
      items: [
        MenuItem(id: 1, name: 'Salmon Sushi', price: 1500, imagePath: 'images/ssushi.jpg'),
        MenuItem(id: 2, name: 'Tuna Sushi', price: 1000, imagePath: 'images/tsushi.jpg'),
        MenuItem(id: 3, name: 'Eel Sushi', price: 1200, imagePath: 'images/sushi.jpg'),
        MenuItem(id: 4, name: 'Tempura Roll', price: 1500, imagePath: 'images/trsushi.jpg'),
        MenuItem(id: 5, name: 'Dragon Roll', price: 2000, imagePath: 'images/dshushi.jpg'),
      ],
    ),

  ];

  late List<Restaurant> filteredRestaurants;

  @override
  void initState() {
    super.initState();
    _user = FirebaseAuth.instance.currentUser;
    filteredRestaurants = restaurants;
  }

  void filterRestaurants(String query) {
    final results = restaurants.where((restaurant) {
      final nameLower = restaurant.name.toLowerCase();
      final descriptionLower = restaurant.description.toLowerCase();
      final searchLower = query.toLowerCase();

      return nameLower.contains(searchLower) || descriptionLower.contains(searchLower);
    }).toList();

    setState(() {
      filteredRestaurants = results;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.teal,
        appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.teal,
        title: Text('Food Time',style: TextStyle(color: Colors.white),
          ),
          actions: [
            IconButton(
              icon: Icon(Icons.person),
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: Text('User Details'),
                      content: Column(
                        mainAxisSize: MainAxisSize.min,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Name: ${_user?.displayName ?? 'N/A'}'),
                          SizedBox(height: 8),
                          Text('Email: ${_user?.email ?? 'N/A'}'),
                        ],
                      ),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: Text('Close',style: TextStyle(color: Colors.teal),),
                        ),
                      ],
                    );
                  },
                );
              },
            ),
          ],
        ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(
              height: 150,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: restaurants.length,
                itemBuilder: (context, index) {
                  final restaurant = restaurants[index];
                  return GestureDetector(
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => RestaurantScreen(restaurant: restaurant),
                        ),
                      );
                    },
                    child: Container(
                      width: 200,
                      margin: EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(8),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black12,
                            blurRadius: 4,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.vertical(top: Radius.circular(8)),
                            child: Image.asset(
                              restaurant.imagePath,
                              height: 90,
                              fit: BoxFit.cover,
                            ),
                          ),
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Text(
                              restaurant.name,
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.teal,
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8.0),
              child: TextField(
                onChanged: filterRestaurants,
                decoration: InputDecoration(
                  hintText: 'Search Restaurants...',
                  prefixIcon: Icon(Icons.search),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8.0),
                    borderSide: BorderSide.none,
                  ),
                  filled: true,
                  fillColor: Colors.white,
                ),
              ),
            ),
            Container(
              alignment: Alignment.centerLeft,
              padding: EdgeInsets.all(8.0),
              child: Text(
                'Restaurants',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.white),
              ),
            ),
            ListView.builder(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              itemCount: filteredRestaurants.length,
              itemBuilder: (context, index) {
                final restaurant = filteredRestaurants[index];
                return GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => RestaurantScreen(restaurant: restaurant),
                      ),
                    );
                  },
                  child: Container(
                    margin: EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(8),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black12,
                          blurRadius: 4,
                          spreadRadius: 2,
                        ),
                      ],
                    ),
                    child: Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Row(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Image.asset(
                              restaurant.imagePath,
                              width: 70,
                              height: 70,
                              fit: BoxFit.cover,
                            ),
                          ),
                          SizedBox(width: 8),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  restaurant.name,
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Colors.teal,
                                  ),
                                ),
                                SizedBox(height: 4),
                                Text(
                                  restaurant.description,
                                  style: TextStyle(fontSize: 12, color: Colors.black54),
                                ),
                                SizedBox(height: 4),
                                Row(
                                  children: [
                                    Icon(Icons.timer, color: Colors.teal, size: 16),
                                    SizedBox(width: 4),
                                    Text(
                                      'Delivery Time: ${restaurant.deliveryTime} min',
                                      style: TextStyle(fontSize: 12, color: Colors.black54),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 2),
                                Row(
                                  children: [
                                    Icon(Icons.money, color: Color(0xFFffd28d), size: 16),
                                    SizedBox(width: 4),
                                    Text(
                                      'Delivery Fee: Rs${restaurant.deliveryFee.toStringAsFixed(2)}',
                                      style: TextStyle(fontSize: 12, color: Colors.black54),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}

