import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:foodtime/homepage.dart';
import 'package:foodtime/signup.dart';
import 'package:foodtime/splash.dart';
import 'login.dart';
import 'firebase_options.dart';



Future main() async {

  WidgetsFlutterBinding.ensureInitialized();

  if (kIsWeb) {
    await Firebase.initializeApp(
      options: FirebaseOptions(
      apiKey: 'AIzaSyDDmVnm6iaZQos7XIhP9vN_lMzr83KmYnI',
      appId: '1:315219476596:android:6aeb0208c9aece3a559121',
      messagingSenderId: '315219476596',
      projectId: 'foodtime-c5b5a',
      // Your web Firebase config options



      )
    );
  } else {
    await Firebase.initializeApp();
  }

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Food Time',
        theme: ThemeData(
        appBarTheme: AppBarTheme(
        // Set the color of the back arrow to white
        iconTheme: IconThemeData(color: Colors.white),
    ),
        ),

      routes: {
        '/': (context) => SplashScreen(
          // Here, you can decide whether to show the LoginPage or HomePage based on user authentication
          child: LoginPage(),
        ),
        '/login': (context) => LoginPage(),
        '/signUp': (context) => SignUpPage(),
        '/home': (context) => HomeScreen(),
      },
    );
  }
}


